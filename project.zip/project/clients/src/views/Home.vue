<template>
  <div class="relative">
    <Toast />
    <ConfirmDialog></ConfirmDialog>
    <Map class="z-0" />
    <div class="absolute top-0 right-0 p-2 mr-5">
      <div class="z-2">
        <Button
          class="mx-2 p-button-rounded p-button-secondary"
          icon="pi pi-pencil"
          @click="featureShow()"
        />
        <Button
          class="mx-2 p-button-rounded p-button-secondary"
          icon="pi pi-check"

        />
      </div>
    </div>
  </div>
</template>

<script>
import { useStore } from 'vuex'
import Button from 'primevue/button'
import Map from '../components/Map'

export default {
  setup() {
    const store = useStore()

    return {
      store,
      drawFeatureShow: false,

    }
  },
  methods: {
    featureShow() {
      this.drawFeatureShow = this.$store.state.drawState
      this.$store.dispatch('getDrawState', !this.drawFeatureShow)
    },
  },
  components: {
    Map,
    Button,
  },
  name: 'Home',
}
</script>
