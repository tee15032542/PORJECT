<template>
  <div>
    <ol-map
      ref="map"
      :loadTilesWhileAnimating="trueState"
      :loadTilesWhileInteracting="trueState"
      :style="{ height: '86vh' }"
    >
      <ol-view
        ref="view"
        :center="center"
        :rotation="rotation"
        :zoom="zoom"
        :projection="projection"
      />

      <ol-tile-layer>
        <ol-source-bingmaps
          apiKey="Apm3UN-fY8mbNM6Q56U7Wnfa2mLF7QIi-hFai0YO-QuyagXpfhy3mRWkwR_-PjTN"
          imagerySet="AerialWithLabels"
        />
      </ol-tile-layer>

      <!-- control -->
      <ol-fullscreen-control />
      <ol-mouseposition-control :getCoordinateFormat="position" @render="getPosition" />
      <ol-scaleline-control />
      <ol-zoom-control />
      <ol-zoomslider-control />

      <ol-vector-layer :style="vectorStyle">
        <ol-source-vector :features="zones" :projection="projection">
          <ol-feature>
            <ol-geom-multi-polygon
              :coordinates="[
                [
                  [
                    [100.63721227502869, 14.043463278187867],
                    [100.68496888696346, 14.0331560957559],
                    [100.67844100475655, 13.989522356793902],
                    [100.60697787322825, 13.981276610848326],
                    [100.63721227502869, 14.043463278187867],
                  ],
                ],
                [
                  [
                    [100.64156306801168, 14.1540921702593],
                    [100.89081538734762, 14.276315070649925],
                    [100.89081538734762, 14.095040656587425],
                    [100.73288692055074, 14.03598914291555],
                    [100.64156306801168, 14.1540921702593],
                  ],
                ],
                [
                  [
                    [100.84008006272636, 14.100266689395847],
                    [101.09032446412168, 13.929368233269397],
                    [100.89501170335136, 13.788987448400203],
                    [100.65060456153107, 13.921977732448134],
                    [100.84008006272636, 14.100266689395847],
                  ],
                ],
                [
                  [
                    [100.54212650389549, 13.770780717861204],
                    [100.61963632458207, 13.727181445803971],
                    [100.54575978765479, 13.702354073309268],
                    [100.48073302191234, 13.743762246327464],
                    [100.54212650389549, 13.770780717861204],
                  ],
                ],
              ]"
            ></ol-geom-multi-polygon>
          </ol-feature>
          <ol-interaction-draw
            v-if="store.state.drawState"
            :type="drawType"
            @drawstart="drawStart"
            @drawend="drawEnd"
            @click="setPoint"
            :stopClick="true"
          />
          <ol-interaction-modify v-if="modifyEnabled" :features="selectedFeatures">
          </ol-interaction-modify>
          <ol-interaction-snap v-if="modifyEnabled" />
        </ol-source-vector>

        <ol-style>
          <ol-style-stroke :color="`rgba(0, 153, 153, 1)`" :width="4"></ol-style-stroke>
          <ol-style-fill :color="`rgba(204, 229, 255, 0.5)`"></ol-style-fill>
        </ol-style>
      </ol-vector-layer>

      <ol-interaction-select
        @select="featureSelected"
        :condition="selectCondition"
        :features="selectedFeatures"
      >
        <ol-style>
          <ol-style-stroke color="red" :width="4"></ol-style-stroke>
          <ol-style-fill color="rgba(255,0,0,0.5)"></ol-style-fill>
        </ol-style>
      </ol-interaction-select>
    </ol-map>
    <div>[{{ store.state.geometry }}]</div>
  </div>
</template>

<script>
import { ref, inject, computed } from 'vue'
import { useStore } from 'vuex'
import { Collection } from 'ol'
import { Fill, Stroke, Style } from 'ol/style'
// import axios from 'axios'
export default {
  setup() {
    const map = ref()
    const store = useStore()
    const center = ref([100.60448421058975, 13.788110114595236])
    const projection = ref('EPSG:4326')
    const zoom = ref(8)
    const rotation = ref(0)
    const trueState = ref(true)
    const drawType = ref('Polygon')
    const modifyEnabled = ref(false)

    const zones = ref([])
    const polygonPoints = ref([])
    let polygon = []

    const getPolygon = async () => {
      // console.log(store.getters.getAllGeometry)
      // console.log(store.state.geometry)

      console.log(store.state.geometry)
      const allPolygon = computed(() => store.state.geometry)
      console.log(allPolygon)

      let temp = store.state.userdataall
      let geoLv1 = []
      let geoLv2 = []

      console.log(temp[0].geometry_data)
      for (let i = 0; i < temp.length; i++) {
        console.log(temp[i].geometry_data)

        let eachData = temp[i].geometry_data
          .slice(2, temp[i].geometry_data.length - 3)
          .replaceAll('[', '')
          .replaceAll(']', '')

        const something = eachData.split(',')

        const array = something.map(Number)

        let point = []
        for (let i = 0; i < array.length; i = i + 2) {
          point = [array[i], array[i + 1]]
          //[p,p]
          geoLv1.push(point)
        }
        // [[p,p],[p,p],[p,p],[p,p],[p,p]]

        geoLv2.push(geoLv1)
        // [[[p,p],[p,p],[p,p],[p,p],[p,p]]]

        geoLv1 = []
      }

      // let geoLv1 = []
      // let geoLv2 = []
      // let point = []
      // for(let i = 0; i < array.length ;i=i+2){
      //   point = [array[i],array[i+1]]
      //   geoLv1.push(point)
      // }
      // geoLv2.push(geoLv1)
      // console.log('geo',geoLv2)
      polygon.push(geoLv2)
      let text = polygon.toString()

      console.log(text)
      // console.log('polygon',polygon)
    }
    getPolygon()
    const selectedFeatures = ref(new Collection())

    // login by admin then get all polygon in database

    // Check collapse user's polygon by showing user id

    // When user confirm to save and when user want to delete => delete that id and new polygon

    // One polygon One user

    // Geo

    const onInitZone = async () => {
      // store.state.userGeometry
      // zoe
    }
    onInitZone()

    console.log(getPolygon)
    const drawStart = event => {
      console.log(event)
    }
    const drawEnd = event => {
      console.log(event.feature)
      store.dispatch('putDrawStep', 'end')
      const polygon = event.feature.values_.geometry.flatCoordinates
      var geometryPoint = []
      ;(';')
      for (let i = 0; i < polygon.length; i = i + 2) {
        geometryPoint.push([polygon[i], polygon[i + 1]])
      }
      zones.value.push(event.feature)
      console.log(zones)
      selectedFeatures.value.push(event.feature)
      var geometryJSON = JSON.stringify(geometryPoint)
      console.log(geometryJSON)
      store.dispatch('getgeometrydr', geometryJSON)
      store.dispatch('getDrawState', false)
      modifyEnabled.value = true
    }
    const setPoint = event => {
      console.log(event)
      polygonPoints.value.push()
    }
    const selectConditions = inject('ol-selectconditions')
    const selectCondition = selectConditions.click

    function featureSelected(event) {
      modifyEnabled.value = false
      if (event.selected.length > 0) {
        modifyEnabled.value = true
      }
      selectedFeatures.value = event.target.getFeatures()
    }

    function vectorStyle() {
      const style = new Style({
        stroke: new Stroke({
          color: 'blue',
          width: 3,
        }),
        fill: new Fill({
          color: 'rgba(0, 0, 255, 0.8)',
        }),
      })
      return style
    }
    const position = ref()
    return {
      map,
      store,
      center,
      projection,
      zoom,
      rotation,
      trueState,
      drawType,
      drawStart,
      drawEnd,
      setPoint,
      modifyEnabled,
      getPolygon,
      polygon,
      polygonPoints,
      selectCondition,
      featureSelected,
      vectorStyle,
      position,
    }
  },

  name: 'MapGeo',
}
</script>

<style></style>
