<template>
  <div class="relative">
    <Toast />
    <ConfirmDialog></ConfirmDialog>
    <Map class="z-0" />
    <div class="absolute top-0 right-0 p-2 mr-5">
      <div class="z-2">
        <Button
          class="mx-2 p-button-rounded p-button-secondary"
          icon="pi pi-pencil"
          @click="featureShow()"
        />
        <Button
          class="mx-2 p-button-rounded p-button-secondary"
          icon="pi pi-check"
          @click="confirmDraw()"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { useStore } from 'vuex'
import Button from 'primevue/button'
import Map from '../components/Map'
import axios from 'axios'

export default {
  setup() {
    const store = useStore()

    return {
      store,
      drawFeatureShow: false,
    }
  },
  methods: {
    featureShow() {
      this.drawFeatureShow = this.$store.state.drawState
      this.$store.dispatch('getDrawState', !this.drawFeatureShow)
    },
    confirmDraw() {
      const idname = this.$store.state.userProfile.user_id
      const latlong = this.$store.state.geometrydr
      axios
        .post(`http://localhost:8081/insertUserGeometry`, {
          idname: idname,
          latlong: latlong,
        })
        .then(res => {
          console.log(res)
        })
        .catch(err => {
          console.log(err)
        })
    },
  },
  components: {
    Map,
    Button,
  },
  name: 'Home',
}
</script>
