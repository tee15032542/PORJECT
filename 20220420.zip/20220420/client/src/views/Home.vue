<template>
  <div class="relative">
    <Toast />
    <ConfirmDialog></ConfirmDialog>
    <Dialog
      v-model:visible="displayDialog"
      :style="{ width: '30vw' }"
      :modal="true"
    >
      <template #footer>
        <div class="text-center">
          <Button
            type="button"
            label="Confirm"
            class="p-button-primary p-button-raised"
            style="width: 100px"
          />
        </div>
      </template>
    </Dialog>

    <Map class="z-0" />
    <div class="absolute top-0 right-0 p-2 mr-5">
      <div class="z-2">
        <Button
          v-if="store.state.drawStep == ''"
          class="mx-2 p-button-rounded p-button-secondary"
          icon="pi pi-pencil"
          @click="featureShow()"
        />
        <Button
          v-if="store.state.drawStep == 'end'"
          class="mx-2 p-button-rounded p-button-secondary"
          icon="pi pi-check"
          @click="confirmDraw()"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { useStore } from "vuex";
import Button from "primevue/button";
import Dialog from "primevue/dialog";
import Map from "../components/Map";
import { ref, computed, defineComponent } from "vue";
import axios from "axios";
import { whenever } from "@vueuse/core";

export default defineComponent({
  setup() {
    const store = useStore();
    const displayDialog = ref(true);
    const drawStep = computed(() => store.state.geometry);
    whenever(drawStep, () => {
      if (drawStep.value == "" || drawStep.value == "confirm") {
        displayDialog.value = false;
      }
      if (drawStep.value == "end") {
        displayDialog.value = true;
      }
    });

    return {
      store,
      drawFeatureShow: false,
      displayDialog,
    };
  },
  methods: {
    featureShow() {
      this.drawFeatureShow = this.$store.state.drawState;
      this.$store.dispatch("getDrawState", !this.drawFeatureShow);
      this.$store.dispatch("putDrawStep", "start");
    },
    confirmDraw() {
      const idname = this.$store.state.userProfile.user_id;
      const latlong = this.$store.state.geometrydr;
      axios
        .post(`http://localhost:8081/insertUserGeometry`, {
          idname: idname,
          latlong: latlong,
        })
        .then((res) => {
          console.log(res);
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
  components: {
    Map,
    Button,
    Dialog,
  },
  name: "HomeGeo",
});
</script>
