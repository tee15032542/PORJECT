import { createStore } from "vuex";

export default createStore({
  state: {
    userProfile: null,
    hasLogin: "",
    drawState: false,
    drawStep: "", // start, end, confirm
    geometrydr: "",
    geometry: [],
  },
  getters: {
    getAllGeometry: (state) => {
      return state.geometry;
    },
  },
  mutations: {
    setDrawStep(state, step) {
      state.drawStep = step;
    },
    setUserProfile(state, userProfile) {
      state.userProfile = userProfile;
      if (userProfile == null) {
        state.hasLogin = false;
      } else {
        state.hasLogin = true;
      }
      console.log(state.hasLogin);
    },
    setDrawState(state, drawState) {
      state.drawState = drawState;
    },
    setLoginState(state, loginState) {
      state.hasLogin = loginState;
    },
    setgeometrydr(state, geometrydr) {
      state.geometrydr = geometrydr;
    },
    setGeometry(state, geometry) {
      console.log("setGeometry", geometry);
      state.geometry = [...geometry];
      // geometry.forEach(data => {
      //   console.log(data)
      //   state.geometry.push(data)
      // })
    },
  },
  actions: {
    getUserProfile({ commit }, profile) {
      const noProfile = null;
      console.log(profile);
      profile
        ? commit("setUserProfile", profile)
        : commit("setUserProfile", noProfile);
    },
    getDrawState({ commit }, drawState) {
      commit("setDrawState", drawState);
    },
    getLoginState({ commit }, loginState) {
      commit("setLoginState", loginState);
    },
    getgeometrydr({ commit }, geometrydr) {
      commit("setgeometrydr", geometrydr);
    },
    getGeometry({ commit }, geometry) {
      console.log("getGeometry", geometry);
      commit("setGeometry", geometry);
    },
    putDrawStep({ commit }, step) {
      commit("setDrawStep", step);
    },
  },
  modules: {},
});
